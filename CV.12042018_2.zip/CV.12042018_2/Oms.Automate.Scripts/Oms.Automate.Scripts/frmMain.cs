﻿using Oms.ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace Oms.Automate.Scripts
{
    public partial class Form1 : Form
    {
        private ILogger _logger = new FileLogger();
        private IJobsEngine _jobsEngine = new JobsEngineFiles();

        List<TableLayoutPanel> listScheduleBoxes = new List<TableLayoutPanel>();

        public Form1()
        {
            InitializeComponent();
            ScheduleBoxesList();
            BindScheduleType();
            BindGridJobs();
            BindGridJobStatusLogs();
            BindGridTriggerLogs();
            BindGridExecutionLogs();
        }

        private void ScheduleBoxesList()
        {
            listScheduleBoxes.Add(tblInterval);
            listScheduleBoxes.Add(tblDaily);
            listScheduleBoxes.Add(tblWeekly);
            listScheduleBoxes.Add(tblMonthly);
        }
        private void BindScheduleType()
        {
            comboBoxType.DataSource = Enum.GetValues(typeof(ScheduleTypes));
            comboBoxType.SelectedItem = ScheduleTypes.Select;
            rdoBtnPython.Checked = true;

            comboBoxWeeklyDayOfWeek.DataSource = Enum.GetValues(typeof(DayOfWeek));
            comboBoxWeeklyDayOfWeek.SelectedIndex = 1;
            numMonthlyDayOfMonth.Value = 30;
        }
        private void BindGridJobs()
        {
            //List the scheduled jobs
            IEnumerable<Job> jobs = _jobsEngine.GetAllJobs();
            int i = 1;
            var j = from job in jobs
                    orderby(job.CreatedTime)
                    select new
                    {
                        Num = i++,
                        Id = job.Id,
                        job.ScriptType,
                        job.Description,
                        job.Schedule.ScheduleType,
                        Schedule = GetScheduleToShow(job.Schedule.ScheduleType, job.Schedule),
                        job.CreatedTime,
                        job.FirstOrNextSchedule,
                        job.Interpreter,
                        job.ScriptFilePath
                    };

            dgvJobs.DataSource = j.ToList();

        }
        private void BindGridTriggerLogs()
        {

            //List the scheduled jobs
            IEnumerable<LogTrigger> logs = _jobsEngine.GetTriggerLogs();
            int i = 1;
            var j = from log in logs
                    select new
                    {
                        //Id = i++,
                        TimeStamp = Convert.ToDateTime(log.TimeStamp),
                        Message = log.Content,
                        Job = log.Job != null ? GetJobToShow(log.Job) : string.Empty
                    };

            var list = j.OrderBy(x => x.TimeStamp.Second).OrderByDescending(x => x.TimeStamp.Minute).OrderByDescending(x => x.TimeStamp.Hour);

            dgvTriggerLog.DataSource = list.ToList();
        }
        private void BindGridExecutionLogs()
        {

            //List the scheduled jobs
            IEnumerable<LogExecution> logs = _jobsEngine.GetExecutionLogs();
            int i = 1;
            var j = from log in logs
                    select new
                    {
                        //Id = i++,
                        TimeStamp = Convert.ToDateTime(log.TimeStamp),
                        log.Result.enginetype,
                        log.Result.starttime,
                        log.Result.endtime,
                        log.Result.output,
                        log.Result.error,
                        log.Result.exception
                        //Job = log.Job != null ? GetJobToShow(log.Job) : string.Empty
                    };

            var list = j.OrderBy(x => x.TimeStamp.Second).OrderByDescending(x => x.TimeStamp.Minute).OrderByDescending(x => x.TimeStamp.Hour);

            dgvExecutionLog.DataSource = list.ToList();
        }
        private void BindGridJobStatusLogs()
        {
            //https://www.c-sharpcorner.com/UploadFile/mahesh/working-with-datetime-using-C-Sharp/
            //List the scheduled jobs
            string formatString = "MM/dd/yyyy HH:mm";

            IEnumerable<LogJobStatus> logs = _jobsEngine.GetJobStatusLogs();
            int i = 1;
            var j = from log in logs
                    select new
                    {
                        //TimeStamp = Convert.ToDateTime(log.TimeStamp).ToString(formatString),
                        JobDescription = log.Job.Description.Substring(0, 20) + "...("+ log.JobId.Substring(0, 16) + "...)",
                        //StatusId = log.Status.Split('#')[0].Split('S')[1],
                        log.Status,
                        StartTime = log.StartTime.ToString("u"),
                        EndTime = log.EndTime.ToString("u").Contains("1900") ? string.Empty: log.EndTime.ToString("u"),
                        log.JobId,
                        Job = log.Job != null ? GetJobToShow(log.Job) : string.Empty
                    };
            
            var list = j.OrderBy(x => x.JobId).OrderByDescending(x => x.StartTime);// TimeStamp//.OrderByDescending(x => x.);

            dgvJobStatusLog.DataSource = list.ToList();
        }

        private string GetScheduleToShow(ScheduleTypes scheduleTypes, Schedule schedule)
        {
            //https://docs.microsoft.com/en-us/dotnet/standard/base-types/standard-date-and-time-format-strings
            string schedulestring = string.Empty;
            switch (scheduleTypes)
            {
                case ScheduleTypes.Interval:
                    schedulestring += schedule.IntervalInMinutes.ToString() + " minutes ";
                    break;
                case ScheduleTypes.Daily:
                    schedulestring += schedule.DailyHours.ToString() +" : "+ schedule.DailyMinutes.ToString();
                    break;
                case ScheduleTypes.Weekly:
                    schedulestring += ((DayOfWeek)schedule.WeeklyDayOfWeek).ToString() + ", " + 
                                        schedule.WeeklyHours.ToString()+ " : " + 
                                        schedule.WeeklyMinutes.ToString();
                    break;
                case ScheduleTypes.Monthly:
                    int day = Convert.ToInt32(schedule.MonthlyDayOfMonth);
                    string suffix = (day % 10 == 1 && day != 11) ? "st"
                               : (day % 10 == 2 && day != 12) ? "nd"
                               : (day % 10 == 3 && day != 13) ? "rd"
                                  : "th";
                    schedulestring += schedule.MonthlyDayOfMonth.ToString() + 
                                    suffix + " , " + 
                                    schedule.MonthlyHours.ToString() + " : " + 
                                    schedule.MonthlyMinutes.ToString();
                    break;
            }
            return schedulestring;
        }
        private string GetJobToShow(Job job)
        {
            string str = string.Empty;
            str += "{";
            str += "ScriptType: " + job.ScriptType;
            str += ", Description: " + job.Description;
            str += ", ScheduleType: " + job.Schedule.ScheduleType;
            str += ", Schedule: " + GetScheduleToShow(job.Schedule.ScheduleType, job.Schedule);
            str += ", CreatedTime: " + job.CreatedTime;
            str += ", Interpreter: " + job.Interpreter;
            str += ", ScriptFilePath: " + job.ScriptFilePath;
            str += "}";

            return str;
        }

        private void ShowBrowsedFile(TextBox textBox, string filter)
        {
            string scriptFile = string.Empty;
            scriptFile = BrowseFile(filter);

            if (!string.IsNullOrEmpty(scriptFile))
            {
                textBox.ReadOnly = false;
                textBox.Text = scriptFile;
                textBox.ReadOnly = true;
            }
            else
            {
                MessageBox.Show("Please browse a valid file.");
            }
        }
        private string BrowseFile(string filter)
        {
            string fileName = string.Empty;
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = filter, ValidateNames = true, Multiselect = false })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    fileName = ofd.FileName;
                }
            }

            return fileName;
        }
        private void ShowResults(Results result)
        {
            lblText.Text += new ResultHelperFiles().FormatResultToShow(result) + "\n";
        }
        private void btnBrowseScriptFile_Click(object sender, EventArgs e)
        {
            bool isScriptTypeSelected = false;
            string filter = string.Empty;

            if (rdoBtnPython.Checked)
            {
                isScriptTypeSelected = true;
                filter = FileFilters.PythonFileFilter;
            }
            else if (rdoBtnPython.Checked)
            {
                isScriptTypeSelected = true;
                filter = FileFilters.PythonFileFilter;
            }
            else
                MessageBox.Show("Please choose script type.");

            if (isScriptTypeSelected)
                ShowBrowsedFile(txtScriptFile , filter);
        }
        private void btnChooseInterpreter_Click(object sender, EventArgs e)
        {
            ShowBrowsedFile(txtInterpreter, FileFilters.InterpreterFilter);
        }
        private void btnTestExecution_Click(object sender, EventArgs e)
        {
            //_logger.WriteLog("Admin application has started script.");

            //string fileName = txtScriptFile.Text;// @"D:\python_auto_sample_1.py";
            //string interpreter = txtInterpreter.Text;// @"C:\Program Files (x86)\Microsoft Visual Studio\Shared\Anaconda3_64\python.exe";

            //lblText.Text = string.Empty;
            //lblText.Text += fileName;
            //lblText.Text += "\n" + interpreter + "\n\n";

            //IExecutionEngine pyengine = new PythonExecutionEngine();
            //Results result = pyengine.ExecuteScript(interpreter, fileName);
            //ShowResults(result);


            //IExecutionEngine rengine = new RExecutionEngine();
            //result = rengine.ExecuteScript(interpreter, fileName);
            //ShowResults(result);

            //_logger.WriteLog("Admin application has completed script.");

        }
        private void btnScheduleJob_Click(object sender, EventArgs e)
        {
            Job job = new Job();
            job.Id = Guid.NewGuid();
            job.Interpreter = txtInterpreter.Text;
            job.IsActive = true;
            job.Name = "Name_" + DateTime.Now.ToString().Replace(':', '-');
            job.Description = txtScriptDescription.Text;// "Name_" + DateTime.Now.ToString().Replace(':', '-');
            job.CreatedTime = DateTime.Now;
            job.ScriptFilePath = txtScriptFile.Text;
            job.ScriptType = rdoBtnPython.Checked ? "Python" : "R";

            Schedule schedule = PrepareSchedule();

            DateTime firstSchedule = new ScheduleEngine().GenerateFirstSchedule(schedule);


            job.Schedule = schedule;
            job.FirstOrNextSchedule = firstSchedule;

            string jobId = _jobsEngine.CreateJob(job);
            if (!string.IsNullOrEmpty(jobId))
            {
                lblText.Text = "Job scheduled: " + jobId;
                lblText.Text += Environment.NewLine + "Next schedule: " + firstSchedule.ToString();
            }


            //sbr.AppendLine(string.Format("[schedule.nextSchedule] : {0}", firstSchedule.ToString()));
            //lblText.Text = sbr.ToString();
            BindGridJobs();

        }


        private Schedule PrepareSchedule()
        {

            StringBuilder sbr;
            Schedule schedule = new Schedule();
            schedule.Repeat = chkBoxRepeat.Checked;

            ScheduleTypes selectedType = (ScheduleTypes)comboBoxType.SelectedValue;
            schedule.ScheduleType = selectedType;

            if (!selectedType.Equals(ScheduleTypes.Select))
                switch (selectedType)
                {
                    case ScheduleTypes.Interval:
                        schedule.IntervalInMinutes = Convert.ToInt32(numIntervalInMinutes.Value);
                        break;
                    case ScheduleTypes.Daily:
                        schedule.DailyHours = Convert.ToInt32(numDailyHours.Value);
                        schedule.DailyMinutes = Convert.ToInt32(numDailyMinutes.Value);
                        break;
                    case ScheduleTypes.Weekly:
                        schedule.WeeklyDayOfWeek = Convert.ToInt32(comboBoxWeeklyDayOfWeek.SelectedValue);
                        schedule.WeeklyHours = Convert.ToInt32(numWeeklyHours.Value);
                        schedule.WeeklyMinutes = Convert.ToInt32(numWeeklyMinutes.Value);
                        break;
                    case ScheduleTypes.Monthly:
                        schedule.MonthlyDayOfMonth = Convert.ToInt32(numMonthlyDayOfMonth.Value);
                        schedule.MonthlyHours = Convert.ToInt32(numMonthlyHours.Value);
                        schedule.MonthlyMinutes = Convert.ToInt32(numMonthlyMinutes.Value);
                        break;
                }



            DateTime currentTime = DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy HH:mm"));

            sbr = new StringBuilder();
            sbr.AppendLine(string.Format("CurrentDate] : {0}", DateTime.Now.ToString()));
            sbr.AppendLine(string.Format("Month ] : {0}", DateTime.Now.Month.ToString()));
            sbr.AppendLine(string.Format("dd/MM/yyyy HH:mm] : {0}", currentTime.ToString()));
            sbr.AppendLine(string.Format("[schedule.Repeat] : {0}", schedule.Repeat.ToString()));
            sbr.AppendLine(string.Format("[schedule.ScheduleType] : {0}", schedule.ScheduleType.ToString()));
            sbr.AppendLine(string.Format("[schedule.IntervalInMinutes] : {0}", schedule.IntervalInMinutes.ToString()));
            sbr.AppendLine(string.Format("[schedule.DailyHours] : {0}", schedule.DailyHours.ToString()));
            sbr.AppendLine(string.Format("[schedule.DailyMinutes] : {0}", schedule.DailyMinutes.ToString()));
            sbr.AppendLine(string.Format("[schedule.WeeklyDayOfWeek] : {0}", schedule.WeeklyDayOfWeek.ToString()));
            sbr.AppendLine(string.Format("[schedule.WeeklyHours] : {0}", schedule.WeeklyHours.ToString()));
            sbr.AppendLine(string.Format("[schedule.WeeklyMinutes] : {0}", schedule.WeeklyMinutes.ToString()));
            sbr.AppendLine(string.Format("[schedule.MonthlyDayOfMonth] : {0}", schedule.MonthlyDayOfMonth.ToString()));
            sbr.AppendLine(string.Format("[schedule.MonthlyHours] : {0}", schedule.MonthlyHours.ToString()));
            sbr.AppendLine(string.Format("[schedule.MonthlyMinutes] : {0}", schedule.MonthlyMinutes.ToString()));
            sbr.AppendLine(string.Format(""));
            return schedule;
        }
        
        private void comboBoxType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ScheduleTypes selectedType = (ScheduleTypes)comboBoxType.SelectedValue;
            switch (selectedType)
            {
                case ScheduleTypes.Select:
                    HideScheduleBoxes();
                    break;
                case ScheduleTypes.Daily:
                    ShowScheduleBox(tblDaily);
                    break;
                case ScheduleTypes.Interval:
                    ShowScheduleBox(tblInterval);
                    break;
                case ScheduleTypes.Monthly:
                    ShowScheduleBox(tblMonthly);
                    break;
                case ScheduleTypes.Weekly:
                    ShowScheduleBox(tblWeekly);
                    break;
            }

        }
        private void HideScheduleBoxes()
        {
            foreach (TableLayoutPanel tblPanel in listScheduleBoxes)
            {
                tblPanel.Visible = false;
                grpBoxJobScheduling.Height = 100;
            }
        }
        private void ShowScheduleBox(TableLayoutPanel tblBox)
        {
            foreach( TableLayoutPanel tblPanel in listScheduleBoxes)
            {
                if (tblPanel.Equals(tblBox))
                {
                    tblPanel.Visible = true;
                    tblPanel.Location = tblInterval.Location;
                    grpBoxJobScheduling.Height = 180;
                }
                else
                {
                    tblPanel.Visible = false;
                }
            }
        }

        private void dgvTriggerLog_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in dgvTriggerLog.Rows)
            {
                if (row.Cells[1].Value.ToString().Contains("SA100"))
                {
                    row.DefaultCellStyle.BackColor = Color.LightGray;
                }
            }
            dgvTriggerLog.ClearSelection();
            dgvJobs.ClearSelection();

        }
    }
}
