﻿namespace Oms.Automate.Scripts
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.grpBoxJobScheduling = new System.Windows.Forms.GroupBox();
            this.tblMonthly = new System.Windows.Forms.TableLayoutPanel();
            this.lblDomMonthly = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.numMonthlyHours = new System.Windows.Forms.NumericUpDown();
            this.numMonthlyMinutes = new System.Windows.Forms.NumericUpDown();
            this.lblTodMonthly = new System.Windows.Forms.Label();
            this.numMonthlyDayOfMonth = new System.Windows.Forms.NumericUpDown();
            this.tblWeekly = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.numWeeklyHours = new System.Windows.Forms.NumericUpDown();
            this.numWeeklyMinutes = new System.Windows.Forms.NumericUpDown();
            this.lblTodWeekly = new System.Windows.Forms.Label();
            this.lblDowWeekly = new System.Windows.Forms.Label();
            this.comboBoxWeeklyDayOfWeek = new System.Windows.Forms.ComboBox();
            this.tblDaily = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.numDailyHours = new System.Windows.Forms.NumericUpDown();
            this.numDailyMinutes = new System.Windows.Forms.NumericUpDown();
            this.lblTodDaily = new System.Windows.Forms.Label();
            this.tblInterval = new System.Windows.Forms.TableLayoutPanel();
            this.lblIntervalInMinutes = new System.Windows.Forms.Label();
            this.numIntervalInMinutes = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tblScheduleType = new System.Windows.Forms.TableLayoutPanel();
            this.lblType = new System.Windows.Forms.Label();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.lblRepeat = new System.Windows.Forms.Label();
            this.chkBoxRepeat = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.btnScheduleJob = new System.Windows.Forms.Button();
            this.btnTestExecution = new System.Windows.Forms.Button();
            this.groupBoxScriptDefinition = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtInterpreter = new System.Windows.Forms.TextBox();
            this.btnChooseInterpreter = new System.Windows.Forms.Button();
            this.txtScriptFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.rdoBtnPython = new System.Windows.Forms.RadioButton();
            this.rdoBtnR = new System.Windows.Forms.RadioButton();
            this.lblChooseScriptType = new System.Windows.Forms.Label();
            this.btnBrowseScriptFile1 = new System.Windows.Forms.Button();
            this.lblScriptDescrion = new System.Windows.Forms.Label();
            this.txtScriptDescription = new System.Windows.Forms.TextBox();
            this.lblText = new System.Windows.Forms.Label();
            this.groupBoxJobsLogs = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageJobs = new System.Windows.Forms.TabPage();
            this.dgvJobs = new System.Windows.Forms.DataGridView();
            this.tabPageLogs = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPageJobStatusLog = new System.Windows.Forms.TabPage();
            this.dgvJobStatusLog = new System.Windows.Forms.DataGridView();
            this.tabPageTriggerLog = new System.Windows.Forms.TabPage();
            this.dgvTriggerLog = new System.Windows.Forms.DataGridView();
            this.tabPageExecutionLog = new System.Windows.Forms.TabPage();
            this.dgvExecutionLog = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblOutput = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.grpBoxJobScheduling.SuspendLayout();
            this.tblMonthly.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMonthlyHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMonthlyMinutes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMonthlyDayOfMonth)).BeginInit();
            this.tblWeekly.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numWeeklyHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWeeklyMinutes)).BeginInit();
            this.tblDaily.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDailyHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDailyMinutes)).BeginInit();
            this.tblInterval.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIntervalInMinutes)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            this.tblScheduleType.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBoxScriptDefinition.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBoxJobsLogs.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageJobs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobs)).BeginInit();
            this.tabPageLogs.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPageJobStatusLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobStatusLog)).BeginInit();
            this.tabPageTriggerLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTriggerLog)).BeginInit();
            this.tabPageExecutionLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExecutionLog)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.Controls.Add(this.grpBoxJobScheduling, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.groupBoxScriptDefinition, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblText, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.groupBoxJobsLogs, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 232F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 297F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(968, 639);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // grpBoxJobScheduling
            // 
            this.grpBoxJobScheduling.Controls.Add(this.tblMonthly);
            this.grpBoxJobScheduling.Controls.Add(this.tblWeekly);
            this.grpBoxJobScheduling.Controls.Add(this.tblDaily);
            this.grpBoxJobScheduling.Controls.Add(this.tblInterval);
            this.grpBoxJobScheduling.Controls.Add(this.tableLayoutPanel4);
            this.grpBoxJobScheduling.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpBoxJobScheduling.Location = new System.Drawing.Point(8, 240);
            this.grpBoxJobScheduling.Name = "grpBoxJobScheduling";
            this.grpBoxJobScheduling.Size = new System.Drawing.Size(377, 291);
            this.grpBoxJobScheduling.TabIndex = 3;
            this.grpBoxJobScheduling.TabStop = false;
            this.grpBoxJobScheduling.Text = "Job Scheduling";
            // 
            // tblMonthly
            // 
            this.tblMonthly.ColumnCount = 2;
            this.tblMonthly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.12566F));
            this.tblMonthly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.87434F));
            this.tblMonthly.Controls.Add(this.lblDomMonthly, 0, 0);
            this.tblMonthly.Controls.Add(this.tableLayoutPanel12, 1, 1);
            this.tblMonthly.Controls.Add(this.lblTodMonthly, 0, 1);
            this.tblMonthly.Controls.Add(this.numMonthlyDayOfMonth, 1, 0);
            this.tblMonthly.Dock = System.Windows.Forms.DockStyle.Top;
            this.tblMonthly.Location = new System.Drawing.Point(3, 216);
            this.tblMonthly.Name = "tblMonthly";
            this.tblMonthly.RowCount = 2;
            this.tblMonthly.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.64706F));
            this.tblMonthly.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 57.35294F));
            this.tblMonthly.Size = new System.Drawing.Size(371, 69);
            this.tblMonthly.TabIndex = 5;
            // 
            // lblDomMonthly
            // 
            this.lblDomMonthly.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblDomMonthly.AutoSize = true;
            this.lblDomMonthly.Location = new System.Drawing.Point(55, 7);
            this.lblDomMonthly.Name = "lblDomMonthly";
            this.lblDomMonthly.Size = new System.Drawing.Size(76, 14);
            this.lblDomMonthly.TabIndex = 3;
            this.lblDomMonthly.Text = "Day of month:";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.numMonthlyHours, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.numMonthlyMinutes, 1, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(137, 32);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(231, 34);
            this.tableLayoutPanel12.TabIndex = 0;
            // 
            // numMonthlyHours
            // 
            this.numMonthlyHours.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numMonthlyHours.Location = new System.Drawing.Point(3, 6);
            this.numMonthlyHours.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numMonthlyHours.Name = "numMonthlyHours";
            this.numMonthlyHours.Size = new System.Drawing.Size(109, 22);
            this.numMonthlyHours.TabIndex = 0;
            // 
            // numMonthlyMinutes
            // 
            this.numMonthlyMinutes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numMonthlyMinutes.Location = new System.Drawing.Point(118, 6);
            this.numMonthlyMinutes.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numMonthlyMinutes.Name = "numMonthlyMinutes";
            this.numMonthlyMinutes.Size = new System.Drawing.Size(110, 22);
            this.numMonthlyMinutes.TabIndex = 1;
            // 
            // lblTodMonthly
            // 
            this.lblTodMonthly.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTodMonthly.AutoSize = true;
            this.lblTodMonthly.Location = new System.Drawing.Point(63, 42);
            this.lblTodMonthly.Name = "lblTodMonthly";
            this.lblTodMonthly.Size = new System.Drawing.Size(68, 14);
            this.lblTodMonthly.TabIndex = 4;
            this.lblTodMonthly.Text = "Time of day:";
            // 
            // numMonthlyDayOfMonth
            // 
            this.numMonthlyDayOfMonth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numMonthlyDayOfMonth.Location = new System.Drawing.Point(139, 3);
            this.numMonthlyDayOfMonth.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.numMonthlyDayOfMonth.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numMonthlyDayOfMonth.Name = "numMonthlyDayOfMonth";
            this.numMonthlyDayOfMonth.Size = new System.Drawing.Size(229, 22);
            this.numMonthlyDayOfMonth.TabIndex = 5;
            // 
            // tblWeekly
            // 
            this.tblWeekly.ColumnCount = 2;
            this.tblWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.12566F));
            this.tblWeekly.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.87434F));
            this.tblWeekly.Controls.Add(this.tableLayoutPanel11, 1, 1);
            this.tblWeekly.Controls.Add(this.lblTodWeekly, 0, 1);
            this.tblWeekly.Controls.Add(this.lblDowWeekly, 0, 0);
            this.tblWeekly.Controls.Add(this.comboBoxWeeklyDayOfWeek, 1, 0);
            this.tblWeekly.Dock = System.Windows.Forms.DockStyle.Top;
            this.tblWeekly.Location = new System.Drawing.Point(3, 151);
            this.tblWeekly.Name = "tblWeekly";
            this.tblWeekly.RowCount = 2;
            this.tblWeekly.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tblWeekly.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.tblWeekly.Size = new System.Drawing.Size(371, 65);
            this.tblWeekly.TabIndex = 4;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.numWeeklyHours, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.numWeeklyMinutes, 1, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(137, 32);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(231, 30);
            this.tableLayoutPanel11.TabIndex = 0;
            // 
            // numWeeklyHours
            // 
            this.numWeeklyHours.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numWeeklyHours.Location = new System.Drawing.Point(3, 4);
            this.numWeeklyHours.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numWeeklyHours.Name = "numWeeklyHours";
            this.numWeeklyHours.Size = new System.Drawing.Size(109, 22);
            this.numWeeklyHours.TabIndex = 0;
            // 
            // numWeeklyMinutes
            // 
            this.numWeeklyMinutes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numWeeklyMinutes.Location = new System.Drawing.Point(118, 4);
            this.numWeeklyMinutes.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numWeeklyMinutes.Name = "numWeeklyMinutes";
            this.numWeeklyMinutes.Size = new System.Drawing.Size(110, 22);
            this.numWeeklyMinutes.TabIndex = 1;
            // 
            // lblTodWeekly
            // 
            this.lblTodWeekly.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTodWeekly.AutoSize = true;
            this.lblTodWeekly.Location = new System.Drawing.Point(63, 40);
            this.lblTodWeekly.Name = "lblTodWeekly";
            this.lblTodWeekly.Size = new System.Drawing.Size(68, 14);
            this.lblTodWeekly.TabIndex = 2;
            this.lblTodWeekly.Text = "Time of day:";
            // 
            // lblDowWeekly
            // 
            this.lblDowWeekly.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblDowWeekly.AutoSize = true;
            this.lblDowWeekly.Location = new System.Drawing.Point(60, 7);
            this.lblDowWeekly.Name = "lblDowWeekly";
            this.lblDowWeekly.Size = new System.Drawing.Size(71, 14);
            this.lblDowWeekly.TabIndex = 1;
            this.lblDowWeekly.Text = "Day of week:";
            // 
            // comboBoxWeeklyDayOfWeek
            // 
            this.comboBoxWeeklyDayOfWeek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxWeeklyDayOfWeek.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxWeeklyDayOfWeek.FormattingEnabled = true;
            this.comboBoxWeeklyDayOfWeek.Location = new System.Drawing.Point(139, 3);
            this.comboBoxWeeklyDayOfWeek.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.comboBoxWeeklyDayOfWeek.Name = "comboBoxWeeklyDayOfWeek";
            this.comboBoxWeeklyDayOfWeek.Size = new System.Drawing.Size(229, 22);
            this.comboBoxWeeklyDayOfWeek.TabIndex = 3;
            // 
            // tblDaily
            // 
            this.tblDaily.ColumnCount = 2;
            this.tblDaily.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.12566F));
            this.tblDaily.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.87434F));
            this.tblDaily.Controls.Add(this.tableLayoutPanel10, 1, 0);
            this.tblDaily.Controls.Add(this.lblTodDaily, 0, 0);
            this.tblDaily.Dock = System.Windows.Forms.DockStyle.Top;
            this.tblDaily.Location = new System.Drawing.Point(3, 118);
            this.tblDaily.Name = "tblDaily";
            this.tblDaily.RowCount = 1;
            this.tblDaily.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblDaily.Size = new System.Drawing.Size(371, 33);
            this.tblDaily.TabIndex = 3;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Controls.Add(this.numDailyHours, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.numDailyMinutes, 1, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(137, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(231, 27);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // numDailyHours
            // 
            this.numDailyHours.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numDailyHours.Location = new System.Drawing.Point(3, 3);
            this.numDailyHours.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numDailyHours.Name = "numDailyHours";
            this.numDailyHours.Size = new System.Drawing.Size(109, 22);
            this.numDailyHours.TabIndex = 0;
            // 
            // numDailyMinutes
            // 
            this.numDailyMinutes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numDailyMinutes.Location = new System.Drawing.Point(118, 3);
            this.numDailyMinutes.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numDailyMinutes.Name = "numDailyMinutes";
            this.numDailyMinutes.Size = new System.Drawing.Size(110, 22);
            this.numDailyMinutes.TabIndex = 1;
            // 
            // lblTodDaily
            // 
            this.lblTodDaily.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTodDaily.AutoSize = true;
            this.lblTodDaily.Location = new System.Drawing.Point(63, 9);
            this.lblTodDaily.Name = "lblTodDaily";
            this.lblTodDaily.Size = new System.Drawing.Size(68, 14);
            this.lblTodDaily.TabIndex = 1;
            this.lblTodDaily.Text = "Time of day:";
            // 
            // tblInterval
            // 
            this.tblInterval.ColumnCount = 2;
            this.tblInterval.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.12566F));
            this.tblInterval.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.87434F));
            this.tblInterval.Controls.Add(this.lblIntervalInMinutes, 0, 0);
            this.tblInterval.Controls.Add(this.numIntervalInMinutes, 1, 0);
            this.tblInterval.Dock = System.Windows.Forms.DockStyle.Top;
            this.tblInterval.Location = new System.Drawing.Point(3, 89);
            this.tblInterval.Name = "tblInterval";
            this.tblInterval.RowCount = 1;
            this.tblInterval.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblInterval.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tblInterval.Size = new System.Drawing.Size(371, 29);
            this.tblInterval.TabIndex = 2;
            // 
            // lblIntervalInMinutes
            // 
            this.lblIntervalInMinutes.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblIntervalInMinutes.AutoSize = true;
            this.lblIntervalInMinutes.Location = new System.Drawing.Point(30, 7);
            this.lblIntervalInMinutes.Name = "lblIntervalInMinutes";
            this.lblIntervalInMinutes.Size = new System.Drawing.Size(101, 14);
            this.lblIntervalInMinutes.TabIndex = 0;
            this.lblIntervalInMinutes.Text = "Interval in minutes:";
            // 
            // numIntervalInMinutes
            // 
            this.numIntervalInMinutes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.numIntervalInMinutes.Location = new System.Drawing.Point(139, 3);
            this.numIntervalInMinutes.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.numIntervalInMinutes.Maximum = new decimal(new int[] {
            1339,
            0,
            0,
            0});
            this.numIntervalInMinutes.Name = "numIntervalInMinutes";
            this.numIntervalInMinutes.Size = new System.Drawing.Size(229, 22);
            this.numIntervalInMinutes.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.tblScheduleType, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(371, 71);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // tblScheduleType
            // 
            this.tblScheduleType.ColumnCount = 2;
            this.tblScheduleType.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.07427F));
            this.tblScheduleType.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.92573F));
            this.tblScheduleType.Controls.Add(this.lblType, 0, 0);
            this.tblScheduleType.Controls.Add(this.comboBoxType, 1, 0);
            this.tblScheduleType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblScheduleType.Location = new System.Drawing.Point(3, 34);
            this.tblScheduleType.Name = "tblScheduleType";
            this.tblScheduleType.RowCount = 1;
            this.tblScheduleType.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tblScheduleType.Size = new System.Drawing.Size(365, 34);
            this.tblScheduleType.TabIndex = 0;
            // 
            // lblType
            // 
            this.lblType.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(94, 10);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(34, 14);
            this.lblType.TabIndex = 0;
            this.lblType.Text = "Type:";
            // 
            // comboBoxType
            // 
            this.comboBoxType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxType.FormattingEnabled = true;
            this.comboBoxType.Location = new System.Drawing.Point(136, 6);
            this.comboBoxType.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(226, 22);
            this.comboBoxType.TabIndex = 7;
            this.comboBoxType.SelectedIndexChanged += new System.EventHandler(this.comboBoxType_SelectedIndexChanged);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.07427F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.92573F));
            this.tableLayoutPanel5.Controls.Add(this.lblRepeat, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.chkBoxRepeat, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(365, 25);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // lblRepeat
            // 
            this.lblRepeat.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblRepeat.AutoSize = true;
            this.lblRepeat.Location = new System.Drawing.Point(83, 5);
            this.lblRepeat.Name = "lblRepeat";
            this.lblRepeat.Size = new System.Drawing.Size(45, 14);
            this.lblRepeat.TabIndex = 0;
            this.lblRepeat.Text = "Repeat:";
            // 
            // chkBoxRepeat
            // 
            this.chkBoxRepeat.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chkBoxRepeat.AutoSize = true;
            this.chkBoxRepeat.Checked = true;
            this.chkBoxRepeat.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkBoxRepeat.Location = new System.Drawing.Point(136, 5);
            this.chkBoxRepeat.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.chkBoxRepeat.Name = "chkBoxRepeat";
            this.chkBoxRepeat.Size = new System.Drawing.Size(15, 14);
            this.chkBoxRepeat.TabIndex = 1;
            this.chkBoxRepeat.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 73.44444F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.55556F));
            this.tableLayoutPanel6.Controls.Add(this.btnScheduleJob, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.btnTestExecution, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(8, 537);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(377, 31);
            this.tableLayoutPanel6.TabIndex = 4;
            // 
            // btnScheduleJob
            // 
            this.btnScheduleJob.Location = new System.Drawing.Point(279, 3);
            this.btnScheduleJob.Name = "btnScheduleJob";
            this.btnScheduleJob.Size = new System.Drawing.Size(78, 25);
            this.btnScheduleJob.TabIndex = 8;
            this.btnScheduleJob.Text = "Schedule Job";
            this.btnScheduleJob.UseVisualStyleBackColor = true;
            this.btnScheduleJob.Click += new System.EventHandler(this.btnScheduleJob_Click);
            // 
            // btnTestExecution
            // 
            this.btnTestExecution.Location = new System.Drawing.Point(3, 3);
            this.btnTestExecution.Name = "btnTestExecution";
            this.btnTestExecution.Size = new System.Drawing.Size(107, 25);
            this.btnTestExecution.TabIndex = 0;
            this.btnTestExecution.Text = "Test execution";
            this.btnTestExecution.UseVisualStyleBackColor = true;
            this.btnTestExecution.Click += new System.EventHandler(this.btnTestExecution_Click);
            // 
            // groupBoxScriptDefinition
            // 
            this.groupBoxScriptDefinition.Controls.Add(this.tableLayoutPanel2);
            this.groupBoxScriptDefinition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxScriptDefinition.Location = new System.Drawing.Point(8, 8);
            this.groupBoxScriptDefinition.Name = "groupBoxScriptDefinition";
            this.groupBoxScriptDefinition.Size = new System.Drawing.Size(377, 226);
            this.groupBoxScriptDefinition.TabIndex = 5;
            this.groupBoxScriptDefinition.TabStop = false;
            this.groupBoxScriptDefinition.Text = "Script Definition";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.70642F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.29358F));
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.txtInterpreter, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.btnChooseInterpreter, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.txtScriptFile, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnBrowseScriptFile1, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.lblScriptDescrion, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtScriptDescription, 0, 3);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(371, 205);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose interpreter";
            // 
            // txtInterpreter
            // 
            this.txtInterpreter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtInterpreter.Location = new System.Drawing.Point(3, 116);
            this.txtInterpreter.Name = "txtInterpreter";
            this.txtInterpreter.ReadOnly = true;
            this.txtInterpreter.Size = new System.Drawing.Size(263, 22);
            this.txtInterpreter.TabIndex = 1;
            // 
            // btnChooseInterpreter
            // 
            this.btnChooseInterpreter.Location = new System.Drawing.Point(272, 116);
            this.btnChooseInterpreter.Name = "btnChooseInterpreter";
            this.btnChooseInterpreter.Size = new System.Drawing.Size(78, 24);
            this.btnChooseInterpreter.TabIndex = 2;
            this.btnChooseInterpreter.Text = "Choose interpreter";
            this.btnChooseInterpreter.UseVisualStyleBackColor = true;
            this.btnChooseInterpreter.Click += new System.EventHandler(this.btnChooseInterpreter_Click);
            // 
            // txtScriptFile
            // 
            this.txtScriptFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtScriptFile.Location = new System.Drawing.Point(3, 175);
            this.txtScriptFile.Name = "txtScriptFile";
            this.txtScriptFile.ReadOnly = true;
            this.txtScriptFile.Size = new System.Drawing.Size(263, 22);
            this.txtScriptFile.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 14);
            this.label2.TabIndex = 5;
            this.label2.Text = "Browse script file(s)";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 131F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.rdoBtnPython, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.rdoBtnR, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblChooseScriptType, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(263, 26);
            this.tableLayoutPanel3.TabIndex = 7;
            // 
            // rdoBtnPython
            // 
            this.rdoBtnPython.AutoSize = true;
            this.rdoBtnPython.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdoBtnPython.Location = new System.Drawing.Point(134, 3);
            this.rdoBtnPython.Name = "rdoBtnPython";
            this.rdoBtnPython.Size = new System.Drawing.Size(60, 20);
            this.rdoBtnPython.TabIndex = 0;
            this.rdoBtnPython.TabStop = true;
            this.rdoBtnPython.Text = "Python";
            this.rdoBtnPython.UseVisualStyleBackColor = true;
            // 
            // rdoBtnR
            // 
            this.rdoBtnR.AutoSize = true;
            this.rdoBtnR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdoBtnR.Location = new System.Drawing.Point(200, 3);
            this.rdoBtnR.Name = "rdoBtnR";
            this.rdoBtnR.Size = new System.Drawing.Size(60, 20);
            this.rdoBtnR.TabIndex = 1;
            this.rdoBtnR.TabStop = true;
            this.rdoBtnR.Text = "R";
            this.rdoBtnR.UseVisualStyleBackColor = true;
            // 
            // lblChooseScriptType
            // 
            this.lblChooseScriptType.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblChooseScriptType.AutoSize = true;
            this.lblChooseScriptType.Location = new System.Drawing.Point(3, 6);
            this.lblChooseScriptType.Name = "lblChooseScriptType";
            this.lblChooseScriptType.Size = new System.Drawing.Size(96, 14);
            this.lblChooseScriptType.TabIndex = 6;
            this.lblChooseScriptType.Text = "Choose script type";
            // 
            // btnBrowseScriptFile1
            // 
            this.btnBrowseScriptFile1.Location = new System.Drawing.Point(272, 175);
            this.btnBrowseScriptFile1.Name = "btnBrowseScriptFile1";
            this.btnBrowseScriptFile1.Size = new System.Drawing.Size(78, 24);
            this.btnBrowseScriptFile1.TabIndex = 3;
            this.btnBrowseScriptFile1.Text = "Browse script file(s)";
            this.btnBrowseScriptFile1.UseVisualStyleBackColor = true;
            this.btnBrowseScriptFile1.Click += new System.EventHandler(this.btnBrowseScriptFile_Click);
            // 
            // lblScriptDescrion
            // 
            this.lblScriptDescrion.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblScriptDescrion.AutoSize = true;
            this.lblScriptDescrion.Location = new System.Drawing.Point(3, 41);
            this.lblScriptDescrion.Name = "lblScriptDescrion";
            this.lblScriptDescrion.Size = new System.Drawing.Size(92, 14);
            this.lblScriptDescrion.TabIndex = 8;
            this.lblScriptDescrion.Text = "Script description";
            // 
            // txtScriptDescription
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.txtScriptDescription, 2);
            this.txtScriptDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtScriptDescription.Location = new System.Drawing.Point(3, 62);
            this.txtScriptDescription.Name = "txtScriptDescription";
            this.txtScriptDescription.Size = new System.Drawing.Size(365, 22);
            this.txtScriptDescription.TabIndex = 9;
            // 
            // lblText
            // 
            this.lblText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblText.AutoSize = true;
            this.lblText.Location = new System.Drawing.Point(8, 595);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(36, 14);
            this.lblText.TabIndex = 1;
            this.lblText.Text = "label1";
            // 
            // groupBoxJobsLogs
            // 
            this.groupBoxJobsLogs.Controls.Add(this.tabControl1);
            this.groupBoxJobsLogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxJobsLogs.Location = new System.Drawing.Point(391, 8);
            this.groupBoxJobsLogs.Name = "groupBoxJobsLogs";
            this.tableLayoutPanel1.SetRowSpan(this.groupBoxJobsLogs, 3);
            this.groupBoxJobsLogs.Size = new System.Drawing.Size(569, 560);
            this.groupBoxJobsLogs.TabIndex = 6;
            this.groupBoxJobsLogs.TabStop = false;
            this.groupBoxJobsLogs.Text = "Jobs and Logs";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageJobs);
            this.tabControl1.Controls.Add(this.tabPageLogs);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 18);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(563, 539);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPageJobs
            // 
            this.tabPageJobs.Controls.Add(this.dgvJobs);
            this.tabPageJobs.Location = new System.Drawing.Point(4, 23);
            this.tabPageJobs.Name = "tabPageJobs";
            this.tabPageJobs.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageJobs.Size = new System.Drawing.Size(555, 512);
            this.tabPageJobs.TabIndex = 0;
            this.tabPageJobs.Text = "Jobs";
            this.tabPageJobs.UseVisualStyleBackColor = true;
            // 
            // dgvJobs
            // 
            this.dgvJobs.AllowUserToAddRows = false;
            this.dgvJobs.AllowUserToDeleteRows = false;
            this.dgvJobs.AllowUserToResizeColumns = false;
            this.dgvJobs.AllowUserToResizeRows = false;
            this.dgvJobs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvJobs.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvJobs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvJobs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJobs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvJobs.Location = new System.Drawing.Point(3, 3);
            this.dgvJobs.Name = "dgvJobs";
            this.dgvJobs.RowHeadersVisible = false;
            this.dgvJobs.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvJobs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvJobs.Size = new System.Drawing.Size(549, 506);
            this.dgvJobs.TabIndex = 0;
            // 
            // tabPageLogs
            // 
            this.tabPageLogs.Controls.Add(this.tabControl2);
            this.tabPageLogs.Location = new System.Drawing.Point(4, 23);
            this.tabPageLogs.Name = "tabPageLogs";
            this.tabPageLogs.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLogs.Size = new System.Drawing.Size(555, 512);
            this.tabPageLogs.TabIndex = 1;
            this.tabPageLogs.Text = "Logs";
            this.tabPageLogs.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPageJobStatusLog);
            this.tabControl2.Controls.Add(this.tabPageTriggerLog);
            this.tabControl2.Controls.Add(this.tabPageExecutionLog);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(549, 506);
            this.tabControl2.TabIndex = 2;
            // 
            // tabPageJobStatusLog
            // 
            this.tabPageJobStatusLog.Controls.Add(this.dgvJobStatusLog);
            this.tabPageJobStatusLog.Location = new System.Drawing.Point(4, 23);
            this.tabPageJobStatusLog.Name = "tabPageJobStatusLog";
            this.tabPageJobStatusLog.Size = new System.Drawing.Size(541, 479);
            this.tabPageJobStatusLog.TabIndex = 2;
            this.tabPageJobStatusLog.Text = "Job status log";
            this.tabPageJobStatusLog.UseVisualStyleBackColor = true;
            // 
            // dgvJobStatusLog
            // 
            this.dgvJobStatusLog.AllowUserToAddRows = false;
            this.dgvJobStatusLog.AllowUserToDeleteRows = false;
            this.dgvJobStatusLog.AllowUserToResizeColumns = false;
            this.dgvJobStatusLog.AllowUserToResizeRows = false;
            this.dgvJobStatusLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvJobStatusLog.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvJobStatusLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvJobStatusLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJobStatusLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvJobStatusLog.Location = new System.Drawing.Point(0, 0);
            this.dgvJobStatusLog.Name = "dgvJobStatusLog";
            this.dgvJobStatusLog.RowHeadersVisible = false;
            this.dgvJobStatusLog.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvJobStatusLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvJobStatusLog.Size = new System.Drawing.Size(541, 479);
            this.dgvJobStatusLog.TabIndex = 2;
            // 
            // tabPageTriggerLog
            // 
            this.tabPageTriggerLog.Controls.Add(this.dgvTriggerLog);
            this.tabPageTriggerLog.Location = new System.Drawing.Point(4, 23);
            this.tabPageTriggerLog.Name = "tabPageTriggerLog";
            this.tabPageTriggerLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTriggerLog.Size = new System.Drawing.Size(541, 479);
            this.tabPageTriggerLog.TabIndex = 0;
            this.tabPageTriggerLog.Text = "Trigger log";
            this.tabPageTriggerLog.UseVisualStyleBackColor = true;
            // 
            // dgvTriggerLog
            // 
            this.dgvTriggerLog.AllowUserToAddRows = false;
            this.dgvTriggerLog.AllowUserToDeleteRows = false;
            this.dgvTriggerLog.AllowUserToResizeColumns = false;
            this.dgvTriggerLog.AllowUserToResizeRows = false;
            this.dgvTriggerLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvTriggerLog.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvTriggerLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvTriggerLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTriggerLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTriggerLog.Location = new System.Drawing.Point(3, 3);
            this.dgvTriggerLog.Name = "dgvTriggerLog";
            this.dgvTriggerLog.RowHeadersVisible = false;
            this.dgvTriggerLog.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvTriggerLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvTriggerLog.Size = new System.Drawing.Size(535, 473);
            this.dgvTriggerLog.TabIndex = 1;
            this.dgvTriggerLog.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvTriggerLog_DataBindingComplete);
            // 
            // tabPageExecutionLog
            // 
            this.tabPageExecutionLog.Controls.Add(this.lblOutput);
            this.tabPageExecutionLog.Controls.Add(this.dgvExecutionLog);
            this.tabPageExecutionLog.Location = new System.Drawing.Point(4, 23);
            this.tabPageExecutionLog.Name = "tabPageExecutionLog";
            this.tabPageExecutionLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageExecutionLog.Size = new System.Drawing.Size(541, 479);
            this.tabPageExecutionLog.TabIndex = 1;
            this.tabPageExecutionLog.Text = "Execution log";
            this.tabPageExecutionLog.UseVisualStyleBackColor = true;
            // 
            // dgvExecutionLog
            // 
            this.dgvExecutionLog.AllowUserToAddRows = false;
            this.dgvExecutionLog.AllowUserToDeleteRows = false;
            this.dgvExecutionLog.AllowUserToResizeColumns = false;
            this.dgvExecutionLog.AllowUserToResizeRows = false;
            this.dgvExecutionLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvExecutionLog.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvExecutionLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvExecutionLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExecutionLog.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvExecutionLog.Location = new System.Drawing.Point(3, 3);
            this.dgvExecutionLog.Name = "dgvExecutionLog";
            this.dgvExecutionLog.RowHeadersVisible = false;
            this.dgvExecutionLog.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvExecutionLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvExecutionLog.Size = new System.Drawing.Size(535, 208);
            this.dgvExecutionLog.TabIndex = 2;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(968, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblOutput.Location = new System.Drawing.Point(3, 211);
            this.lblOutput.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.lblOutput.Size = new System.Drawing.Size(322, 24);
            this.lblOutput.TabIndex = 3;
            this.lblOutput.Text = "Click the cell within \'Output\' column above to see detailed output.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 663);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Oms Automate Script";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.grpBoxJobScheduling.ResumeLayout(false);
            this.tblMonthly.ResumeLayout(false);
            this.tblMonthly.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numMonthlyHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMonthlyMinutes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMonthlyDayOfMonth)).EndInit();
            this.tblWeekly.ResumeLayout(false);
            this.tblWeekly.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numWeeklyHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWeeklyMinutes)).EndInit();
            this.tblDaily.ResumeLayout(false);
            this.tblDaily.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numDailyHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDailyMinutes)).EndInit();
            this.tblInterval.ResumeLayout(false);
            this.tblInterval.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIntervalInMinutes)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tblScheduleType.ResumeLayout(false);
            this.tblScheduleType.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.groupBoxScriptDefinition.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBoxJobsLogs.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPageJobs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobs)).EndInit();
            this.tabPageLogs.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPageJobStatusLog.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobStatusLog)).EndInit();
            this.tabPageTriggerLog.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTriggerLog)).EndInit();
            this.tabPageExecutionLog.ResumeLayout(false);
            this.tabPageExecutionLog.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExecutionLog)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnTestExecution;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInterpreter;
        private System.Windows.Forms.Button btnChooseInterpreter;
        private System.Windows.Forms.Button btnBrowseScriptFile1;
        private System.Windows.Forms.TextBox txtScriptFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblChooseScriptType;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RadioButton rdoBtnPython;
        private System.Windows.Forms.RadioButton rdoBtnR;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.Button btnScheduleJob;
        private System.Windows.Forms.GroupBox grpBoxJobScheduling;
        private System.Windows.Forms.TableLayoutPanel tblScheduleType;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.ComboBox comboBoxType;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label lblRepeat;
        private System.Windows.Forms.TableLayoutPanel tblMonthly;
        private System.Windows.Forms.TableLayoutPanel tblWeekly;
        private System.Windows.Forms.TableLayoutPanel tblDaily;
        private System.Windows.Forms.TableLayoutPanel tblInterval;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label lblDomMonthly;
        private System.Windows.Forms.Label lblTodMonthly;
        private System.Windows.Forms.Label lblTodWeekly;
        private System.Windows.Forms.Label lblDowWeekly;
        private System.Windows.Forms.Label lblTodDaily;
        private System.Windows.Forms.Label lblIntervalInMinutes;
        private System.Windows.Forms.NumericUpDown numMonthlyHours;
        private System.Windows.Forms.NumericUpDown numMonthlyMinutes;
        private System.Windows.Forms.NumericUpDown numMonthlyDayOfMonth;
        private System.Windows.Forms.NumericUpDown numWeeklyHours;
        private System.Windows.Forms.NumericUpDown numWeeklyMinutes;
        private System.Windows.Forms.ComboBox comboBoxWeeklyDayOfWeek;
        private System.Windows.Forms.NumericUpDown numDailyHours;
        private System.Windows.Forms.NumericUpDown numDailyMinutes;
        private System.Windows.Forms.NumericUpDown numIntervalInMinutes;
        private System.Windows.Forms.CheckBox chkBoxRepeat;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.GroupBox groupBoxScriptDefinition;
        private System.Windows.Forms.Label lblScriptDescrion;
        private System.Windows.Forms.TextBox txtScriptDescription;
        private System.Windows.Forms.GroupBox groupBoxJobsLogs;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageJobs;
        private System.Windows.Forms.TabPage tabPageLogs;
        private System.Windows.Forms.DataGridView dgvJobs;
        private System.Windows.Forms.DataGridView dgvTriggerLog;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPageTriggerLog;
        private System.Windows.Forms.TabPage tabPageExecutionLog;
        private System.Windows.Forms.DataGridView dgvExecutionLog;
        private System.Windows.Forms.TabPage tabPageJobStatusLog;
        private System.Windows.Forms.DataGridView dgvJobStatusLog;
        private System.Windows.Forms.Label lblOutput;
    }
}

