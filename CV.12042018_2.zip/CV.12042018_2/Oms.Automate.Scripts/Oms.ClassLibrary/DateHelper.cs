﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public static class DateHelper
    {
        public static string FormatDateForFileName(DateTime dateTime)
        {
            return string.Join("_", dateTime.Year, dateTime.Month, dateTime.Day);
        }
    }
}
