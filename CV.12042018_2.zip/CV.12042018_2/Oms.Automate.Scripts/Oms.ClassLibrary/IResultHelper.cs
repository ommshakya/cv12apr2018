﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public interface IResultHelper
    {
        string FormatResultToSave(Results result);
        string FormatResultToShow(Results result);
        string FormatResultShort(Results result, Job job);

    }
}
