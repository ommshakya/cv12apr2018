﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Oms.ClassLibrary
{
    public class ResultHelperFiles : IResultHelper
    {
        public string FormatResultToShow(Results result)
        {
            string res = string.Empty;
            res += "Engine type : " + result.enginetype;

            res += Environment.NewLine + "\nOutput \n" + Environment.NewLine;
            res += result.output;

            if (!string.IsNullOrEmpty(result.error))
            {
                res += "\nError \n";
                res += result.error;
            }

            if (!string.IsNullOrEmpty(result.exception))
            {
                res += "\nException \n";
                res += result.exception;
            }
            return res;
        }
        public string FormatResultToSave(Results result)
        {

            var res = new JavaScriptSerializer().Serialize(result);
            
            return res;
        }
        public string FormatResultShort(Results result, Job job)
        {
            var jsonJob = new JavaScriptSerializer().Serialize(job);

            string res = string.Empty;
            string status = string.IsNullOrEmpty(result.error) ? "ES104 # Success" : "ES104 # Failed";
            res = string.Format("jobid |:| {0}; status |:| {1}; starttime |:| {2}; endtime |:| {3}; job |:| {4}"
                                , job.Id, status, result.starttime, result.endtime, jsonJob);
            return res;
        }
    }
}
