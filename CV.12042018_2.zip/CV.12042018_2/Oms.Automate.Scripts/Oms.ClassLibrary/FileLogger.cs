﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class FileLogger : ILogger
    {
        private DateTime CurrentDate { get { return DateTime.Now; } }
        private string SpecialFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "OmsAutomateScripts\\");

        public void WriteError(string error)
        {
            WriteMessage(error, false, false);
        }
        public void WriteLog(string log)
        {
            WriteMessage(log, true, false);
        }
        public void WriteEngineLog(string path, string log)
        {
            WriteEngineMessage(path, log, false);
        }
        public void WriteShortLog(string log)
        {
            WriteShortMessage(log, false);
        }

        private void WriteMessage(string message, bool isLog, bool appendBlankLine = true)
        {
            try
            {
                string fullFilePath = string.Empty;
                if (isLog)
                    fullFilePath = SpecialFolder + "LogsTrigger\\" + "Log_" + DateHelper.FormatDateForFileName(CurrentDate) + ".txt";
                else
                    fullFilePath = SpecialFolder + "LogsTrigger\\" + "Error_" + DateHelper.FormatDateForFileName(CurrentDate) + ".txt";

                WriteToFile(message, appendBlankLine, fullFilePath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private void WriteEngineMessage(string fileName, string message, bool appendBlankLine = true)
        {

            try
            {
                string folder = SpecialFolder + "LogsExecution\\";
                string fullFilePath = Path.Combine(folder, "Output_Log_" + DateHelper.FormatDateForFileName(CurrentDate) + "_" + fileName + ".txt");

                WriteToFile(message, appendBlankLine, fullFilePath);

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private void WriteShortMessage(string message, bool appendBlankLine = true)
        {

            try
            {
                string folder = SpecialFolder + "LogsJobStatus\\";
                string fullFilePath = Path.Combine(folder, "ShortLog.txt");

                WriteToFile(message, appendBlankLine, fullFilePath);

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private void WriteToFile(string message, bool appendBlankLine, string fullFilePath)
        {
            if (!Directory.Exists(Path.GetDirectoryName(fullFilePath)))
                Directory.CreateDirectory(Path.GetDirectoryName(fullFilePath));

            if (!File.Exists(fullFilePath))
                using (FileStream fs = File.Create(fullFilePath)) { fs.Close(); }

            if (File.Exists(fullFilePath))
                using (StreamWriter sw = File.AppendText(fullFilePath))
                {
                    sw.WriteLine(CurrentDate.ToString() + "\t" + message.Trim());
                    //sw.WriteLine();
                    if (appendBlankLine)
                        sw.WriteLine();
                    sw.Close();
                }
        }
    }
}
