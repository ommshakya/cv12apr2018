﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Oms.ClassLibrary
{
    public class AutomationServiceEngine
    {
        private ILogger _logger = new FileLogger();
        private IJobsEngine _jobsEngine = new JobsEngineFiles();
        private IResultHelper _resultProcessor = new ResultHelperFiles();
        private ScheduleEngine _scheduleEngine = new ScheduleEngine();

        public void StartAutomation()
        {
            string formatString = "MM/dd/yyyy HH:mm";
            DateTime currentTime = DateTime.Now;
            string currenttime = currentTime.ToString(formatString);



            var jobsToStart = _jobsEngine.GetAllJobs().Where(x => x.FirstOrNextSchedule.ToString(formatString).Equals(currenttime));
            //var jobsToStart = _jobsEngine.GetAllJobs();

            _logger.WriteLog("SA200: Number of jobs schedule at this time are # "+ jobsToStart.Count().ToString());

            System.Threading.Thread.Sleep(1 * 1000);

            foreach (Job job in jobsToStart)
            {
                if (job.FirstOrNextSchedule.ToString(formatString).Equals(currenttime))
                {
                    var jsonJob = new JavaScriptSerializer().Serialize(job);

                    string msg = string.Format("SA201: Processing job id # {0} Job # {1} # {2}"
                                                , job.Id, jsonJob, "Starting thread...");
                    _logger.WriteLog(msg);

                    Thread thread = new Thread(new ParameterizedThreadStart(StartExecution));
                    thread.Start(job);

                    System.Threading.Thread.Sleep(2 * 1000);

                    //Update next schedule
                    job.FirstOrNextSchedule = _scheduleEngine.GenerateNextSchedule(job.Schedule, job.FirstOrNextSchedule);
                    _jobsEngine.UpdateJob(job);
                }
            }

        }
        private void StartExecution(object obj)
        {
            try
            {
                Job job = (Job)obj;
                _logger.WriteLog("SA202: Initiated the execution of script...");

                IExecutionEngine engine = null;
                if (job.ScriptType.Equals("Python"))
                    engine = new PythonExecutionEngine();
                if (job.ScriptType.Equals("R"))
                    engine = new RExecutionEngine();

                Results result = null;
                if (engine != null)
                    result = engine.ExecuteScript(job);

                string fileName = new JobHelper().CreateId(job);

                if (result != null)
                {
                    LogResultsFull(result, fileName);
                    LogResultsShort(result, job);
                }
            }
            catch (Exception ex)
            {
                _logger.WriteLog(string.Format("SA203: Exception occured # {0}", ex.Message));
                throw;
            }
        }
        private void LogResultsFull(Results result, string fileName)
        {
            string res = string.Empty;
            res = _resultProcessor.FormatResultToSave(result);
            Console.WriteLine(_resultProcessor.FormatResultToShow(result));

            _logger.WriteEngineLog(fileName, res);
        }
        private void LogResultsShort(Results result, Job job)
        {
            string jobresult = _resultProcessor.FormatResultShort(result, job);
            _logger.WriteShortLog(jobresult);

        }
    }
}
