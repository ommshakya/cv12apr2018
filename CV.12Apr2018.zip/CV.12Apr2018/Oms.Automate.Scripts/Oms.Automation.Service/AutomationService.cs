﻿using Oms.ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Web.Script.Serialization;

namespace Oms.Automation.Service
{
    public partial class AutomationService : ServiceBase
    {
        private System.Timers.Timer timerMain = null;
        private ILogger _logger = new FileLogger();
        private IJobsEngine _jobsEngine = new JobsEngineFiles();
        private IResultHelper _resultProcessor = new ResultHelperFiles();

        public AutomationService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            timerMain = new System.Timers.Timer();
            timerMain.Interval = 60 * 1000;// 60 seconds
            timerMain.Elapsed += new System.Timers.ElapsedEventHandler(timerMain_Elapsed);
            timerMain.Enabled = true;

            _logger.WriteLog("S101: Service started.");
        }

        protected override void OnStop()
        {
            timerMain.Enabled = false;
            _logger.WriteLog("S103: Service stopped.");
        }

        private void timerMain_Elapsed(object sender, ElapsedEventArgs e)
        {
            _logger.WriteLog("S102: Service activated.");

            new AutomationServiceEngine().StartAutomation();
        }
    }
}
