﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class Schedule
    {
        public ScheduleTypes ScheduleType { get; set; }
        public bool Repeat { get; set; }
        public int? IntervalInMinutes { get; set; }
        public int? DailyHours { get; set; }
        public int? DailyMinutes { get; set; }
        public int? WeeklyDayOfWeek { get; set; }
        public int? WeeklyHours { get; set; }
        public int? WeeklyMinutes { get; set; }
        public int? MonthlyDayOfMonth { get; set; }
        public int? MonthlyHours { get; set; }
        public int? MonthlyMinutes { get; set; }
    }
}
