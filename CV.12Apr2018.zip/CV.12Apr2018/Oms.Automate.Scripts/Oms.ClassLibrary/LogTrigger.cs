﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class LogTrigger
    {
        public DateTime TimeStamp { get; set; }
        public string Content { get; set; }
        public Job Job { get; set; }
    }
}
