﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class Job
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ScriptType { get; set; }
        public string ScriptFilePath { get; set; }
        public string Interpreter { get; set; }
        public DateTime CreatedTime { get; set; }
        public bool IsActive { get; set; }
        public Schedule Schedule { get; set; }
        public DateTime FirstOrNextSchedule { get; set; }
    }
    
}
